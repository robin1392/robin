﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("quantum.console.runner")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("quantum.console.runner")]
[assembly: AssemblyCopyright("Copyright © Exit Games 2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b2c620e4-13f8-4ecd-a7f0-88724216e90c")]
[assembly: AssemblyVersion("2.0.1")]
[assembly: AssemblyFileVersion("2.0.1")]
[assembly: AssemblyInformationalVersion("2.0.1 F1 684 2.0.1/release (725e415da)")]
